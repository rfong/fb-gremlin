//chrome.browserAction.onClicked.addListener(function(tab) {
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo) {
  chrome.tabs.insertCSS( null, {file:"style.css"} );
  chrome.tabs.executeScript( null, {file:"detect_tagging.js"} );
});